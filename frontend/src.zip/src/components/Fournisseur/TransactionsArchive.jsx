import React from "react";
export default function TransactionsArchive() {
  return <div className="p-3"><h5>Transactions — Archive</h5></div>;
}
