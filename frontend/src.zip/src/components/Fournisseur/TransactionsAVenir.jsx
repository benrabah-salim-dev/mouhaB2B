import React from "react";
export default function TransactionsAVenir() {
  return <div className="p-3"><h5>Transactions — À venir</h5></div>;
}
