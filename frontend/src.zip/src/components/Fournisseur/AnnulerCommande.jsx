import React from "react";
export default function AnnulerCommande() {
  return <div className="p-3"><h5>Annuler une commande</h5></div>;
}
