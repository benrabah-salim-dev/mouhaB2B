import React from "react";
export default function PaiementsBanques() {
  return <div className="p-3"><h5>Paiements et banques</h5></div>;
}
