import React from "react";
export default function GestionTarifs() {
  return <div className="p-3"><h5>Gestion des tarifs</h5></div>;
}
