import React from "react";
export default function TransactionsEnCours() {
  return <div className="p-3"><h5>Transactions — En cours</h5></div>;
}
