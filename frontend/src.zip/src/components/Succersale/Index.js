export { default as SuccursaleHome } from "./Home";
