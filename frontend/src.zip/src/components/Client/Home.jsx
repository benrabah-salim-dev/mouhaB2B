import React from "react";
export default function Home() {
  return (
    <div className="p-3">
      <h4 className="mb-3">Tableau de bord — Espace client</h4>
      <div className="alert alert-secondary">Contenu à définir.</div>
    </div>
  );
}
